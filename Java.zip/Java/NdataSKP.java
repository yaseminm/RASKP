	
package dataStructures;
import java.io.*;
import java.util.*;
//import ilog.concert.*;
//import ilog.cplex.*;


class NdataSKP
{
	static int supplier = 1;
	static int customer = 1;
	static int num = 0;

	
	private static final int A = 48271;
	private static final int M = 2147483647;
	private static final int Q = M / A;
	private static final int R = M % A;

	/**
	 * Construct this stochasticknapsackdom object with
	 * initial state obtained from system clock.
	 */
	public NdataSKP()
	{
		this((int)(System.currentTimeMillis() % Integer.MAX_VALUE));
	}

	/**
	 * Construct this 
	 object with
	 * specified initial state.
	 * @param initialValue the initial state.
	 */
	public NdataSKP(int initialValue)
	{
		if (initialValue < 0)
			initialValue += M;

		state = initialValue;
		if (state == 0)
			state = 1;
	}

	/**
	 * Return a pseudorandom int, and change the
	 * internal state.
	 * @return the pseudorandom int.
	 */
	public int nextInt()
	{
		int tmpState = A * (state % Q) - R * (state / Q);
		if (tmpState >= 0)
			state = tmpState;
		else
			state = tmpState + M;

		return state;
	}

	/**
	 * Return a pseudorandom int in range [0..high),
	 * and change the internal state.
	 * @return the pseudorandom int.
	 */
	public int nextInt(int high)
	{
		return nextInt() % high;
	}





	public double uniform()
	{
		return nextDouble() % 1;
	}
	private double nextNextGaussian;
 private boolean haveNextNextGaussian = false;

 public double nextGaussian() {
   if (haveNextNextGaussian) {
     haveNextNextGaussian = false;
     return nextNextGaussian;
   } else {
     double v1, v2, s;
     do {
       v1 = 2 * nextDouble() - 1;   // between -1.0 and 1.0
       v2 = 2 * nextDouble() - 1;   // between -1.0 and 1.0
       s = v1 * v1 + v2 * v2;
     } while (s >= 1 || s == 0);
     double multiplier = StrictMath.sqrt(-2 * StrictMath.log(s)/s);
     nextNextGaussian = v2 * multiplier;
     haveNextNextGaussian = true;
     return v1 * multiplier;
   }
 }
	
public double normal(double sd, double m)
	{
		return (nextGaussian()*sd)+m;
	}
	/**
	 * Return an int in the closed range [low,high], and
	 * change the internal state.
	 * @param low the minimum value returned.
	 * @param high the maximum value returned.
	 * @return the pseudorandom int.
	 */
	public int nextInt(int low, int high)
	{
		double partitionSize = (double)M / (high - low + 1);

		return (int)(nextInt() / partitionSize) + low;
	}

	public double nextDouble(int low, int high)
	{
		double partitionSize = (double)M / (high - low + 1);

		return (nextInt() / partitionSize) + low;
	}

public double nextDDouble(double low, double high)
	{
		double partitionSize = (double)M / (high - low );

		return (nextInt() / partitionSize) + low;
	}
public static double[] DDouble(int customer, double low, double high)
	{
		double[] M = new double[customer];

		NdataSKP k = new NdataSKP();

		for (int i = 0; i < customer; i++)
		{
			M[i] = k.nextDDouble(low, high);
		}

		return M;
	}


	
	private int state;


	/**
	 * Return a pseudorandom double in the open range 0..1
	 * and change the internal state.
	 * @return the pseudorandom double.
	 */
	public double nextDouble()
	{
		return (double)nextInt() / M;
	}
	
	public static double[] Reli(int customer)
	{
		double[] Mi = new double[customer];

		NdataSKP m = new NdataSKP();

		for (int i = 0; i < customer; i++)
		{
			//Mi[i] = m.nextDouble();
		Mi[i]=(m.nextInt(1, 100));
Mi[i]=Mi[i]/100;
		
	}

		return Mi;
	}

	public static double[] Mean(int customer, int low, int high)
	{
		double[] Mean = new double[customer];

		NdataSKP k = new NdataSKP();

		for (int i = 0; i < customer; i++)
		{
			Mean[i] = k.nextInt(low, high);
		}

		return Mean;
	}


	
  public static int getNormal(double lambda) {
  double L = Math.exp(-lambda);
  double p = 1.0;
  int k = 0;

  do {
    k++;
    p *= Math.random();
  } while (p > L);

  return k - 1;
}


	
	public static void main(String[] args) throws IOException
	{
		System.out.println("yasemin");
		NdataSKP r = new NdataSKP();
		
	
	int customer = 0;
		for (int c = 1; c < 6; c++)
		{
	if (c == 1)
			{
				customer = 5;
			}
			
			if (c == 2)
			{
				customer = 10;
			}
			if (c == 3)
			{
				customer = 25;
			}
			if (c == 4)
			{
				customer = 50;
			}
			if (c == 5)
			{
				customer =100;
			}		
		if (c == 6)
			{
				customer =200;
			}		
	
	if (c == 7)
			{
				customer =300;
			}		
		if (c == 8)
			{
				customer =400;
			}		
		if (c == 9)
			{
				customer =500;
			}	
			
	
				for (int y =1 ; y < 11; y++)
				{

			
							FileOutputStream out1; // declare a file output object
							PrintStream print1; // declare a print stream object  
						
double UR[] = new double[customer];
						double Mean[] = new double[customer];
						double SdD[] = new double[customer];
						double S[] = new double[customer];												
							double L=0;							
							double U=0;

							double sub = r.nextInt(25, 35);
							double sal = r.nextInt(0, 0);
							double cap = 75 * customer;
							double unitrev=15;
							
						for (int i=0; i < customer; i++)
						
							{
								
							Mean[i] = r.nextInt(100, 200);
							/*int alt=(int)M[i]/8;
							int ust=(int)M[i]/4;
							SdD[i] = r.nextInt(alt, ust);
							*/
							SdD[i] = r.nextInt(10, 30);
							
							 S[i] =  r.nextInt(500, 1200);
								
							UR[i] = unitrev*Mean[i]-S[i];
							}

							
			for (int run = 1; run < 2; run++)
			{
			
				out1 = new FileOutputStream("SKPriskNormalSize" + customer + "case" + y + "run"+run+".txt");
							print1 = new PrintStream(out1);

							print1.println("S(i) fixedcost");
							print1.println("/");

							for (int i = 0; i < customer; i++)
							{
								print1.println("" + i + " " + S[i] + "");
							}
							print1.println("/");

							
							
							print1.println("rev(i) revenue rM(i)-S(i)*");
							print1.println("/");

							for (int i = 0; i < customer; i++)
							{
								print1.println("" + i + " " + UR[i] + "");
							}
							print1.println("/");


							print1.println("mean(i) mean");
							print1.println("/");


							for (int i = 0; i < customer; i++)
							{
								print1.println("" + i + " " + Mean[i] + "");
							}
							
							print1.println("/");

							print1.println("s(i) standarddev");
							print1.println("/");

							for (int i = 0; i < customer; i++)
							{
								print1.println("" + i + " " + SdD[i] + "");
							}
							print1.println("/");

						
							
							print1.println("" + sub + "");
							print1.println("" + unitrev + "");
							print1.println("" + cap + "");
							print1.println("" + L + "");
							print1.println("" + U + "");
				
							int scen=1000;
						
					
							double scenarios[][] = new double[scen][customer];
							
								
							for (int j = 0; j <customer; j++)
							{	
							for (int i = 0; i < scen; i++)
							{
								NdataSKP a = new NdataSKP();
							scenarios[i][j] = r.normal( SdD[j],Mean[j]);
							}}		
					
							print1.println("/");	
							double show;
							print1.println("Item Scenarios");
							print1.println("/");
								for(int i = 0;i<scen;i++)
								{
								
									for(int j = 0; j < customer; j++)
									{
										show = scenarios[i][j];
										
										
										if (show<0)
											{
											show=0;
											}
											
													double finalValue = Math.round(show * 1.0 ) / 1.0;
										show=finalValue;
										print1.print(""+show+" ");
								              }
									
									print1.println();
								}
							
							print1.println("/");
							
					
					
							
							
				}
			}
	}
}
}



