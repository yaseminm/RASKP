package dataStructures;
import java.io.*;
import java.util.*;

class SKPriskGAMSpoisson
{
	static int customer = 5;
	public static double pdf(double z)
	{
		double f = 0;
		double pi = 3.14159265358979323846;
		double num = -1 * 0.5 * z * z;
		double num1 = Math.sqrt(2 * pi);
		f = 1 / num1;
		f = f * Math.exp(num);
		return f;
	}

	/** @return n! */
	public static int factorial(int n)
	{
		if (n <= 1)
			return 1;
		else
			return n * factorial(n - 1);
	}



	public static double cdf(double z)
	{
		double zabs;
		double p;
		double expntl, pdf;

		final double p0 = 220.2068679123761;
		final double p1 = 221.2135961699311;
		final double p2 = 112.0792914978709;
		final double p3 = 33.91286607838300;
		final double p4 = 6.373962203531650;
		final double p5 = .7003830644436881;
		final double p6 = .3526249659989109E-01;

		final double q0 = 440.4137358247522;
		final double q1 = 793.8265125199484;
		final double q2 = 637.3336333788311;
		final double q3 = 296.5642487796737;
		final double q4 = 86.78073220294608;
		final double q5 = 16.06417757920695;
		final double q6 = 1.755667163182642;
		final double q7 = .8838834764831844E-1;

		final double cutoff = 7.071;
		final double root2pi = 2.506628274631001;

		zabs = Math.abs(z);

		//  |z| > 37

		if (z > 37.0)
		{

			p = 1.0;

			return p;

		}

		if (z < -37.0)
		{

			p = 0.0;

			return p;

		}

		//  |z| <= 37.

		expntl = Math.exp(-.5 * zabs * zabs);

		pdf = expntl / root2pi;

		//  |z| < cutoff = 10/sqrt(2).

		if (zabs < cutoff)
		{

			p = expntl * ((((((p6 * zabs + p5) * zabs + p4) * zabs + p3) * zabs +
				p2) * zabs + p1) * zabs + p0) / (((((((q7 * zabs + q6) * zabs +
				q5) * zabs + q4) * zabs + q3) * zabs + q2) * zabs + q1) * zabs +
				q0);

		}
		else
		{

			p = pdf / (zabs + 1.0 / (zabs + 2.0 / (zabs + 3.0 / (zabs + 4.0 /
				(zabs + 0.65)))));

		}

		if (z < 0.0)
		{

			return p;

		}
		else
		{

			p = 1.0 - p;

			return p;

		}

	}



	public static double loss(double z)
	{
		MultipleExact r = new MultipleExact();
		double pdf = r.pdf(z);
		double cdf = r.cdf(z);
		double loss = pdf - z * (1 - cdf);
		return loss;
	}
	public static double[][] BubbleSort(int MAXLENGTH, double b[])
	{
		int i, j;
		double temp;
		double temp2;
		double customerered[][] = new double[2][MAXLENGTH];

		for (i = MAXLENGTH - 1; i >= 0; i--)
		{
			customerered[0][i] = i;
			customerered[1][i] = b[i];
		}

		for (i = MAXLENGTH - 1; i >= 0; i--)
		{

			for (j = 0; j < i; j++)
			{
				if (customerered[1][j] > customerered[1][j + 1])
				{
					temp = customerered[1][j];

					customerered[1][j] = customerered[1][j + 1];

					customerered[1][j + 1] = temp;

					temp2 = customerered[0][j];

					customerered[0][j] = customerered[0][j + 1];

					customerered[0][j + 1] = temp2;

				}
			}
		}
		return customerered;
	}

	
	
	public static double InversePoisson(double p)
	{
		double arg, t, t2, t3, xnum, xden, qinvp, x, pc;
		final double c[] = {2.515517, 
      .802853,
      .010328};

		final double d[] = {1.432788,
      .189269,
      .001308};
double round=0;

		if (p <= .5)
		{

			arg = -2.0 * Math.log(p);
			t = Math.sqrt(arg);
			t2 = t * t;
			t3 = t2 * t;

			xnum = c[0] + c[1] * t + c[2] * t2;
			xden = 1.0 + d[0] * t + d[1] * t2 + d[2] * t3;
			qinvp = t - xnum / xden;
			x = -qinvp;
round=Math.round(x*1000);
x=round/1000;
			return x;

		}

		else
		{

			pc = 1.0 - p;
			arg = -2.0 * Math.log(pc);
			t = Math.sqrt(arg);
			t2 = t * t;
			t3 = t2 * t;

			xnum = c[0] + c[1] * t + c[2] * t2;
			xden = 1.0 + d[0] * t + d[1] * t2 + d[2] * t3;
			x = t - xnum / xden;
round=Math.round(x*1000);
x=round/1000;

			return x;
		}

	}

	public static void main(String[] args) throws IOException
	{
			
	int customer = 0;
		
			
 FileOutputStream out3; // declare a file output object
		PrintStream print3; // declare a print stream object  

		out3 = new FileOutputStream("SKPriskGAMSscriptPOISSON.gms");
		print3 = new PrintStream(out3);

		print3.println("*GAMSIDE script V1");
for (int c = 1; c <6; c++)
		{
	if (c == 1)
			{
				customer = 5;
			}
			
			if (c == 2)
			{
				customer = 10;
			}
			if (c == 3)
			{
				customer = 25;
			}
			if (c == 4)
			{
				customer = 50;
			}
			if (c == 5)
			{
				customer = 100;
			}		

 
String solve="LINDOGlobal";

double alf=0;
double pd=0;	

for (int solv = 0; solv < 1;solv++)
{			
	if (solv==0)
	
		{solve="LINDOGlobal";}
if (solv==1)
	
		{solve="DICOPT";}
	
if (solv==2)
	
		{solve="SBB";}
	
if (solv==3)
	
		{solve="Bonmin";}

double beta=0;
for (int sl = 3; sl <4; sl++)
{
if (sl==0)
		{
	beta=0;
	alf=0;
	
		}
	
	if (sl==1)
		{
			beta=2.5;
			alf=0.5;
		}

	if (sl==2)
		{
			beta=5;
			alf=0.90;
		}	
if (sl==3)
		{
			beta=0.9;
			alf=0.90;
		}

if (sl==4)
		{
			beta=15;
			alf=0.99;
		}

if (sl==5)
		{
			beta=20;
			alf=0.999;
		}

		
		double zalfa=InversePoisson(alf);
			
for (int ca = 1; ca < 2; ca++)

		{

for (int con =0 ; con <6; con++)
				{		
				for (int rel = 1; rel <2; rel++)
					{

			for (int y = 1; y < 11; y++)
			{
				
			
				print3.println("fileopen;%ProjDir%SKPriskGAMSpoisson"+sl+"type="+con+"relaxed"+rel+ "run" + ca + "cust" + customer + "case" + y + ".gms;");
				print3.println("filerun;%ProjDir%SKPriskGAMSpoisson"+sl+"type="+con+"relaxed"+rel+ "run" + ca + "cust" + customer + "case" + y + ".gms; gdx=SKPriskGAMSpoisson"+sl+"type="+con+"relaxed"+rel+ "run"  + ca + "cust" + customer + "case" + y + "");
				print3.println("filewait;%ProjDir%SKPriskGAMSpoisson"+sl+"type="+con+"relaxed"+rel+ "run"  + ca + "cust" + customer + "case" + y + ".gms;");
				print3.println("fileopen;%ProjDir%SKPriskGAMSpoisson"+sl+"type="+con+"relaxed"+rel+ "run" + ca + "cust" + customer + "case" + y + ".lst;");
				print3.println("fileopen;%ProjDir%SKPriskGAMSpoisson"+sl+"type="+con+"relaxed"+rel+ "run"  + ca + "cust" + customer + "case" + y + ".gdx;");
				print3.println("fileclose;%ProjDir%SKPriskGAMSpoisson"+sl+"type="+con+"relaxed"+rel+ "run" + ca + "cust" + customer + "case" + y + ".gms;");
				print3.println("fileclose;%ProjDir%SKPriskGAMSpoisson"+sl+"type="+con+"relaxed"+rel+ "run" + ca + "cust" + customer + "case" + y + ".lst;");
				print3.println("fileclose;%ProjDir%SKPriskGAMSpoisson"+sl+"type="+con+"relaxed"+rel+ "run"  + ca + "cust" + customer + "case" + y + ".gdx;");


				SKPriskGAMSpoisson r = new SKPriskGAMSpoisson();
				FileOutputStream out2; // declare a file output object
				PrintStream print2; // declare a print stream object  

				out2 = new FileOutputStream("SKPriskGAMSpoisson"+sl+"type="+con+"relaxed"+rel+ "run" + ca + "cust" + customer + "case" + y + ".gms");
				print2 = new PrintStream(out2);

				///read data
	File datam = new File("SKPriskPoissonSize"+customer+"case" + y + "run"+ca+".txt");

				if (datam.exists())
				{
					
					// Create the buffered reader for reading the file                                                                           
					BufferedReader inFFile = new BufferedReader(new FileReader(datam));
					String Fline = inFFile.readLine();
					StringTokenizer Fst = new StringTokenizer(Fline);
					Fline = inFFile.readLine();


					//start solving
					double FC[] = new double[customer];
					double rr[] = new double[customer];
					double m[] = new double[customer];
					double sdd[] = new double[customer];
					double sc = 0;
					double sv = 0;
					double cc = 0;
					double LB = 0;
					double UB = 0;

					int cus = customer - 1;

int senaryo=10000;
int seniseni= senaryo - 1;

					print2.println("Sets");
					print2.println("i customers /0*" + cus + "/");
					print2.println("Parameters");
					
					
					print2.println("FC(i) fixedcost");
					print2.println("/");
					// Get the first line of the file
					for (int i = 0; i < customer; i++)
					{
						Fline = inFFile.readLine();
						Fst = new StringTokenizer(Fline);
						double reven = new Double(Fst.nextToken()).doubleValue();
						FC[i] = new Double(Fst.nextToken()).doubleValue();
						print2.println("" + i + " " + FC[i] + "");

					}
					Fline = inFFile.readLine();
					Fline = inFFile.readLine();
					Fline = inFFile.readLine();
print2.println("/");
					print2.println("rev(i) revenue");
					print2.println("/");
					// Get the first line of the file
					for (int i = 0; i < customer; i++)
					{
						Fline = inFFile.readLine();
						Fst = new StringTokenizer(Fline);
						double reven = new Double(Fst.nextToken()).doubleValue();
						rr[i] = new Double(Fst.nextToken()).doubleValue();
						print2.println("" + i + " " + rr[i] + "");

					}
					Fline = inFFile.readLine();
					Fline = inFFile.readLine();
					Fline = inFFile.readLine();

					print2.println("/");
					print2.println("mean(i) mean");
					print2.println("/");
					for (int i = 0; i < customer; i++)
					{
						Fline = inFFile.readLine();
						Fst = new StringTokenizer(Fline);
						double meen = new Double(Fst.nextToken()).doubleValue();
						m[i] = new Double(Fst.nextToken()).doubleValue();
						print2.println("" + i + " " + m[i] + "");
					}
					Fline = inFFile.readLine();
					Fline = inFFile.readLine();
					Fline = inFFile.readLine();

					print2.println("/");
					print2.println("s(i) standarddev");
			
					print2.println("$offdigit ");
			
					print2.println("/");

					for (int i = 0; i < customer; i++)
					{
						Fline = inFFile.readLine();
						Fst = new StringTokenizer(Fline);
						double sdev = new Double(Fst.nextToken()).doubleValue();
						sdd[i] = new Double(Fst.nextToken()).doubleValue();
						sdd[i] = Math.sqrt(m[i]);
					
						print2.println("" + i + " " + sdd[i] + "");

					}
					
					
					
					
					Fline = inFFile.readLine();
					Fline = inFFile.readLine();

					print2.println("/");
					Fst = new StringTokenizer(Fline);
					sc = new Double(Fst.nextToken()).doubleValue();

					Fline = inFFile.readLine();
					Fst = new StringTokenizer(Fline);
					sv = new Double(Fst.nextToken()).doubleValue();
double revenue=sv;
									
					Fline = inFFile.readLine();
					Fst = new StringTokenizer(Fline);
					double capac = new Double(Fst.nextToken()).doubleValue();
						
				print2.println("rowac(i) ");
				print2.println("$offdigit ");
				print2.println("/");
					
				double ac[] = new double[customer];
				for (int i = 0; i < customer; i++)
					{
						ac[i]=rr[i]/(sdd[i]*sdd[i]);
						print2.println("" + i + " " + ac[i] + "");

					}
					print2.println("/");

		if (con==0)
		{
print2.println("Scalar type E / 0 /;");
							}
			if (con==1)
		{
					print2.println("Scalar type FR MSD / 1 /;");
					print2.println("Scalar beta risklevel / "+beta+" /;");
		}
			if (con==2)
		{
				print2.println("Scalar type FC MSD / 2 /;");
					print2.println("Scalar beta risklevel / "+beta+" /;");
	}
			if (con==3)
		{
			print2.println("Scalar type FR CVaR / 3 /;");
		}			
					
			if (con==4)
		{
			print2.println("Scalar type FR CVaR / 4 /;");
		}
			if (con==5)
		{
			print2.println("Scalar type FC CVaR / 5 /;");
		}
					
					print2.println("Scalar oo overflow cost /" + sc + "/;");
					print2.println("Scalar revenue rev /"+ revenue+" /;");
					print2.println("Scalar Q capacity / "+capac+" /;");					
					print2.println("Scalar a significance / "+alf+" /;");
					print2.println("Scalar zalfa zvalue for alfa /" + zalfa + "/;");
					print2.println("Parameter r(i) ; ");
					print2.println("r(i) =rev(i) ; ");
					
					print2.println("Variables ");
					print2.println("x(i) selection variable");
					
					print2.println("Sdev standardDev ");
					print2.println("VAR ");
					print2.println("ms ");
					print2.println("msa ");
					print2.println("msa");
					print2.println("SQR ");
					
					print2.println("z0 service level");
						if (con==5)
		{
			print2.println("z1 serviceo");
			print2.println("z2 serviceo+a");
			
			print2.println("pdf1 ");
					print2.println("cdf1 ");
					print2.println("loss1  loss value ");
					
					print2.println("pdf2 ");
					print2.println("cdf2");
					print2.println("loss2  loss value ");
		}
		
		if (con==2)
		{
		print2.println("pv ");
		}			
					print2.println("pdf0 ");
					print2.println("cdf0 ");
					print2.println("loss0  loss value ");
										
										print2.println("orev");
										print2.println("ocost");
										print2.println("objective; ");
										
										print2.println("Binary variable x; ");
											if (con==2)
		{
		print2.println("Positive variable pv; ");
		}	
										
										print2.println("Equations");
										print2.println("expec define objective function");
						if (con==2)
		{
		print2.println(" pvv define pv ");
		}	
					if (con==5)
		{
					print2.println("l1 define lossconst");
					print2.println("cdd1 define cdfconstraint");
					print2.println("ppp1 define pdfconstraint");			
		
					print2.println("l2 define lossconst");
					print2.println("cdd2 define cdfconstraint");
					print2.println("qq0 define zconstraint");
					print2.println("ppp2 define pdfconstraint");		
		
					print2.println("zsum define zumconstraint");		
					print2.println("zkim define zumconstraint");		
		
		}
					
					print2.println("l0 define lossconst");
					print2.println("cdd0 define cdfconstraint");
					print2.println("qq0 define zconstraint");
					print2.println("ppp0 define pdfconstraint");		
					
					
					
					print2.println("sss define sconstraint");
					print2.println("aa define uydurconst");
					print2.println("bb define uydurukconst");
			
					print2.println("msdc define cost");
					print2.println("msam define cost");
	
					print2.println("ocosti define cost");
				print2.println("orevi define rev;");
				
						
			if (con==0)
		{
					print2.println("expec.. objective=e= orev;");	
					print2.println("orevi.. orev=e=  sum((i), r(i)*x(i))-oo*ms;");
					print2.println("ocosti.. ocost=e=  0 ;");	
					print2.println("msam.. msa=e=loss0 ;");	
					print2.println("msdc.. ms=e=VAR*loss0;");	

		}
			if (con==1)
		{
					print2.println("expec.. objective=e= orev-beta*ocost;");	
					print2.println("orevi.. orev=e=  sum((i), r(i)*x(i))-oo*VAR*loss0;");
					print2.println("ocosti.. ocost=e=  oo*VAR*ms ;");		
					print2.println("msam.. msa=e=( (1-cdf0)- loss0*(z0+loss0));");	
					print2.println("msdc.. ms=e=sqrt(msa);");	
					
				
		}
			if (con==2)
		{
print2.println("expec.. objective=e= orev-beta*ocost;");	
print2.println("orevi.. orev=e=  sum((i), r(i)*x(i))-oo*VAR*loss0;");
print2.println("pvv.. pv=e=  sqrt(ms) ;");
print2.println("ocosti.. ocost=e=  VAR*pv ;");
print2.println("msam.. msa=e=( (1-cdf0)- loss0*(z0+loss0));");
print2.println("msdc.. ms=e=(revenue*revenue+oo*oo*msa-2*revenue*oo*(1-cdf0));");

				
		}
		if (con==3)
		{
				print2.println("expec.. objective=e=  sum((i), r(i)*x(i))-oo*ms;");	
					print2.println("orevi.. orev=e=  sum((i), r(i)*x(i))-oo*VAR*loss0;");

					
					print2.println("ocosti.. ocost=e=  0 ;");	
					print2.println("msam.. msa=e=loss0/(1-a) ;");	
					print2.println("msdc.. ms=e=VAR*msa;");	
		}
		
			if (con==4)
		{
					print2.println("expec.. objective=e= orev;");	
					print2.println("orevi.. orev=e=  sum((i), r(i)*x(i))-oo*ms;");
					print2.println("ocosti.. ocost=e=  0 ;");	
					print2.println("msam.. msa=e=(pdf0/(1-a))-z0 ;");	
					print2.println("msdc.. ms=e=VAR*msa;");	
					}
			
		
		if (con==5)
		{
					print2.println("expec.. objective=e= sum((i), r(i)*x(i))-ms;");	
					print2.println("orevi.. orev=e=  sum((i), r(i)*x(i))-oo*VAR*loss0;");
					print2.println("ocosti.. ocost=e=  0 ;");	
					print2.println("msam.. msa=e=(1/(1-a))*(revenue*a*z1+revenue*loss1+(oo-revenue)*loss2);");	
					print2.println("msdc.. ms=e=VAR*msa;");
		
		}
					print2.println("qq0.. Q=e=sum((i),mean(i)*x(i))+z0*VAR;");
					print2.println("sss.. Sdev=e=sum((i),power(s(i),2)*x(i));");
					print2.println("bb.. VAR=e= sqrt (Sdev);");
					print2.println("aa.. SQR=e=sqrt(2*3.14156);");
					
					if (con==5)
		{
					print2.println("ppp1.. pdf1*SQR=e=exp(-0.5*power(z1,2));");
					print2.println("cdd1.. cdf1=e= errorf(z1);");
					print2.println("l1.. loss1=e= pdf1-z1*(1-cdf1);");
					
					print2.println("ppp2.. pdf2*SQR=e=exp(-0.5*power(z2,2));");
					print2.println("cdd2.. cdf2=e= errorf(z2);");
					print2.println("l2.. loss2=e= pdf2-z2*(1-cdf2);");		
					
					print2.println("zsum..z0=e= (revenue/oo)*z1+((oo-revenue)/oo)*z2;");			
					print2.println("zkim..cdf2=e=cdf1+a;");			
		
		}
					print2.println("ppp0.. pdf0*SQR=e=exp(-0.5*power(z0,2));");
					print2.println("cdd0.. cdf0=e= errorf(z0);");
					print2.println("l0.. loss0=e= pdf0-z0*(1-cdf0);");
					
					
		if (con==3)
		{
		
					print2.println("z0.up = 20;");
					print2.println("z0.lo = -zalfa;");
		}
		else
		{
			if (con==4)
		{
		
					print2.println("z0.up = zalfa;");
					print2.println("z0.lo = -20;");
		}
		else
		{
					print2.println("z0.up = 20;");
					print2.println("z0.lo = -20;");
		}
		}
		
					print2.println("cdf0.up = 1;");
					print2.println("cdf0.lo = 0;");
					
					print2.println("Model SKPknapsack /all/ ;");
					print2.println("option minlp="+solve+" ;");

					print2.println("option optcr=1e-5; ");
					print2.println("option iterlim=100000000;");
					print2.println("option reslim=5000; ");
					print2.println("option domlim=20000;");

					print2.println("solve  SKPknapsack using minlp maximizing objective ;");
					
										}}}}}}}}}}