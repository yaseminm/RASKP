package dataStructures;
import java.io.*;
import java.util.*;


class SKPGAMSBuyuk
{
	static int customer = 5;


	public static void main(String[] args) throws IOException
	{
			
	int customer = 0;
		
			
 FileOutputStream out3; // declare a file output object
		PrintStream print3; // declare a print stream object  

		out3 = new FileOutputStream("SKPGAMSBuyukSCRIPT.gms");
		print3 = new PrintStream(out3);

		print3.println("*GAMSIDE script V1");
for (int c = 1; c < 6; c++)
		{
	if (c == 1)
			{
				customer = 5;
			}
			
			if (c == 2)
			{
				customer = 10;
			}
			if (c == 3)
			{
				customer = 25;
			}
			if (c == 4)
			{
				customer = 50;
			}
			if (c == 5)
			{
				customer = 100;
			}		

			
			if (c == 6)
			{
				customer =200;
			}		
	
	if (c == 7)
			{
				customer =300;
			}		
		if (c == 8)
			{
				customer =400;
			}		
		if (c == 9)
			{
				customer =500;
			}	
		
int supplier=customer;				
 
String solve="LINDOGlobal";

double alf=0;
double pd=0;			

	double beta=0;

	for (int sl = 0; sl <1; sl++)
{
if (sl==0)
		{
	beta=0.90;
	alf=0.90;
	
		}
	
	if (sl==1)
		{
			beta=2.5;
			alf=0.5;
		}

	if (sl==2)
		{
			beta=5;
			alf=0.90;
		}	
if (sl==3)
		{
			beta=10;
			alf=0.95;
		}

if (sl==4)
		{
			beta=15;
			alf=0.99;
		}

if (sl==5)
		{
			beta=20;
			alf=0.999;
		}

		for (int ca = 1; ca < 2; ca++)

		{
for (int con = 0; con <6; con++)
					{
						
						if (con==1 || con==2)
						{
						for (int rel = 1; rel <2; rel++)
							{

			for (int y = 1; y < 11; y++)
			{
				
				
			
				print3.println("fileopen;%ProjDir%SKPGAMSBuyuk"+sl+"type="+con+"relaxed"+rel+ "run" + ca + "cust" + customer + "case" + y + ".gms;");
				print3.println("filerun;%ProjDir%SKPGAMSBuyuk"+sl+"type="+con+"relaxed"+rel+ "run" + ca + "cust" + customer + "case" + y + ".gms; gdx=SKPGAMSBuyuk"+sl+"type="+con+"relaxed"+rel+ "run"  + ca + "cust" + customer + "case" + y + "");
				print3.println("filewait;%ProjDir%SKPGAMSBuyuk"+sl+"type="+con+"relaxed"+rel+ "run"  + ca + "cust" + customer + "case" + y + ".gms;");
				print3.println("fileopen;%ProjDir%SKPGAMSBuyuk"+sl+"type="+con+"relaxed"+rel+ "run" + ca + "cust" + customer + "case" + y + ".lst;");
				print3.println("fileopen;%ProjDir%SKPGAMSBuyuk"+sl+"type="+con+"relaxed"+rel+ "run"  + ca + "cust" + customer + "case" + y + ".gdx;");
				print3.println("fileclose;%ProjDir%SKPGAMSBuyuk"+sl+"type="+con+"relaxed"+rel+ "run" + ca + "cust" + customer + "case" + y + ".gms;");
				print3.println("fileclose;%ProjDir%SKPGAMSBuyuk"+sl+"type="+con+"relaxed"+rel+ "run" + ca + "cust" + customer + "case" + y + ".lst;");
				print3.println("fileclose;%ProjDir%SKPGAMSBuyuk"+sl+"type="+con+"relaxed"+rel+ "run"  + ca + "cust" + customer + "case" + y + ".gdx;");


				SKPGAMSBuyuk r = new SKPGAMSBuyuk();
				FileOutputStream out2; // declare a file output object
				PrintStream print2; // declare a print stream object  

out2 = new FileOutputStream("SKPGAMSBuyuk"+sl+"type="+con+"relaxed"+rel+ "run" + ca + "cust" + customer + "case" + y + ".gms");
				
				
				print2 = new PrintStream(out2);

				///read data
				double []  x=new double[supplier];
					
String lstname =("SKPriskGAMSpoisson3type="+con+"relaxed"+rel+ "run" + ca + "cust" + supplier + "case" + y + ".lst");
				
File lst = new File(lstname);		
if (lst.exists())						
{
					
						//print2.println("//lst file buldu");
	
		BufferedReader inFFFile = new BufferedReader(new FileReader(lst));
							String FFFline = null;
							StringBuffer contents1 = new StringBuffer();
			

							String llword = null;

							while ((FFFline = inFFFile.readLine()) != null)
							{
					
if (FFFline.contains("---- VAR x "))
								{
									//print2.println("//x line buldu");
									
									FFFline =inFFFile.readLine();
									FFFline =inFFFile.readLine();
									FFFline =inFFFile.readLine();
					
									for (int u=0;u<supplier;u++)
									{
									FFFline =inFFFile.readLine();
									StringTokenizer variables= new StringTokenizer(FFFline);
									llword = variables.nextToken();	
									llword = variables.nextToken();
									llword = variables.nextToken();
									
								String nokta= new String();
								nokta=".";
									if (llword.equals(nokta))
									{
									x[u]=0;
									}
									else
									{

									x[u] = new Double(llword).doubleValue();
									}
						
									//print2.print(""+x[u]+" ");
									}
									}}}


					
File datam = new File("PoissonDataSon" + customer + "case" + y + "run11.txt");
				if (datam.exists())
				{
							//print2.println("//datam file bulundu");
									
				// Create the buffered reader for reading the file                                                                           
					BufferedReader inFFile = new BufferedReader(new FileReader(datam));
					String Fline = inFFile.readLine();
					StringTokenizer Fst = new StringTokenizer(Fline);
					Fline = inFFile.readLine();


					//start solving
					double rr[] = new double[customer];
					double m[] = new double[customer];
					double sdd[] = new double[customer];
					double FC[] = new double[customer];
					double s[] = new double[customer];
					
					double sc = 0;
					double sv = 0;
					double cc = 0;
					double LB = 0;
					double UB = 0;

					int cus = customer - 1;

int senaryo=10000;
int seniseni= senaryo - 1;

					print2.println("Sets");
					print2.println("i customers /0*" + cus + "/");
					print2.println("w  scenario /0*" + seniseni + "/");							
					print2.println("Parameters");
					
					print2.println("x(i) fixedcost");
					print2.println("/");
					// Get the first line of the file
					for (int i = 0; i < customer; i++)
					{
						
						print2.println("" + i + " " + x[i] + "");

					}
print2.println("/");
					
					
					print2.println("FC(i) fixedcost");
					print2.println("/");
					// Get the first line of the file
					for (int i = 0; i < customer; i++)
					{
						Fline = inFFile.readLine();
						Fst = new StringTokenizer(Fline);
						double reven = new Double(Fst.nextToken()).doubleValue();
						FC[i] = new Double(Fst.nextToken()).doubleValue();
						print2.println("" + i + " " + FC[i] + "");

					}
					Fline = inFFile.readLine();
					Fline = inFFile.readLine();
					Fline = inFFile.readLine();
print2.println("/");
					
					print2.println("rev(i) revenue");
					print2.println("/");
					// Get the first line of the file
					for (int i = 0; i < customer; i++)
					{
						Fline = inFFile.readLine();
						Fst = new StringTokenizer(Fline);
						double reven = new Double(Fst.nextToken()).doubleValue();
						rr[i] = new Double(Fst.nextToken()).doubleValue();
						print2.println("" + i + " " + rr[i] + "");

					}
					Fline = inFFile.readLine();
					Fline = inFFile.readLine();
					Fline = inFFile.readLine();

					print2.println("/");
					print2.println("mean(i) mean");
					print2.println("/");
					for (int i = 0; i < customer; i++)
					{
						Fline = inFFile.readLine();
						Fst = new StringTokenizer(Fline);
						double meen = new Double(Fst.nextToken()).doubleValue();
						m[i] = new Double(Fst.nextToken()).doubleValue();
						print2.println("" + i + " " + m[i] + "");
					}
					Fline = inFFile.readLine();
					Fline = inFFile.readLine();
					Fline = inFFile.readLine();

					print2.println("/");
					print2.println("s(i) standarddev");
					print2.println("/");

					for (int i = 0; i < customer; i++)
					{
						Fline = inFFile.readLine();
						Fst = new StringTokenizer(Fline);
						double sdev = new Double(Fst.nextToken()).doubleValue();
						sdd[i] = new Double(Fst.nextToken()).doubleValue();
						print2.println("" + i + " "+s[i]+"");

					}
					Fline = inFFile.readLine();
					Fline = inFFile.readLine();

					print2.println("/");
					Fst = new StringTokenizer(Fline);
					sc = new Double(Fst.nextToken()).doubleValue();

					Fline = inFFile.readLine();
					Fst = new StringTokenizer(Fline);
					sv = new Double(Fst.nextToken()).doubleValue();
					double revenue=sv;
									
						Fline = inFFile.readLine();
					Fst = new StringTokenizer(Fline);
					double capac = new Double(Fst.nextToken()).doubleValue();
					
					
					
										Fline = inFFile.readLine();
										Fline = inFFile.readLine();
										Fline = inFFile.readLine();
										Fline = inFFile.readLine();
										Fline = inFFile.readLine();
										
										
									double [][]SEN=new double[senaryo][customer];
										
									double [][]senrev=new double[senaryo][customer];
									
										print2.println("Table SEN(w,i) scenario");
							
										print2.print ("     ");
										for (int j = 0; j < customer; j++)
										{
										
										if (j<=9)
										
										{
										print2.print("" + j + "     ");
										}
										else
										{
												if (j<=99)
										
													{
														print2.print("" + j + "    ");
									
													}
													else{
											
													print2.print("" + j + "   ");}
																		
													}
										}
										
										for (int i = 0; i <senaryo ; i++)
										{
										print2.println ("  ");
								
								if(i<=9)
										{
										print2.print("" + i + "    ");
										}
										else
										{
										if(i<=99)
										{
										print2.print("" + i + "   ");
										}
										else
										{
										if(i<=999)
										{
										print2.print("" + i + "  ");
										}
										else
										{
										if(i<=9999)
										{
										print2.print("" + i + " ");
										}
										}
										
										}
									}
										
										
									
										Fline = inFFile.readLine();
											Fst = new StringTokenizer(Fline);
									
											
											for (int j = 0; j < customer; j++)
										{
										
										SEN[i][j] = new Double(Fst.nextToken()).doubleValue();
									
										
String text = Double.toString(Math.abs(SEN[i][j]));
int dp = text.length() ;

										print2.print(""+SEN[i][j] + "");
									   if(dp==5)
											{print2.print(" ");}
										if(dp==4)
												{print2.print("  ");}
										if(dp==3)
												{print2.print("   ");}
										
										}
										}
										
							
										print2.print(";");
			
										print2.println (" ");
					
										
								
										if (con==0)
		{
print2.println("Scalar type E / 0 /;");
							}
			if (con==1)
		{
					print2.println("Scalar type FR MSD / 1 /;");
					print2.println("Scalar beta risklevel / "+beta+" /;");
		}
			if (con==2)
		{
				print2.println("Scalar type FC MSD / 2 /;");
					print2.println("Scalar beta risklevel / "+beta+" /;");
	}
			if (con==3)
		{
			print2.println("Scalar type FR CVaR / 3 /;");
		}			
					
			if (con==4)
		{
			print2.println("Scalar type FR CVaR / 4 /;");
		}
			if (con==5)
		{
			print2.println("Scalar type FC CVaR / 5 /;");
		}
		
				
					print2.println("Scalar oo overflow cost /" + sc + "/;");
					print2.println("Scalar revenue rev /"+ revenue+" /;");
					print2.println("Scalar Q capacity / "+capac+" /;");					
					print2.println("Scalar a significance / "+alf+" /;");
					print2.println("Parameter r(i) ; ");
					print2.println("Parameter rs(w,i) ; ");
			
					print2.println("Variables ");
				//	print2.println("x(i) selection variable");
					
//					print2.println("y(w) force variable");
					print2.println("rterm re");
				
					
					print2.println("VAR var");
					print2.println("SS(w) loss");
										print2.println("T(w) shortage");
										
										print2.println("reterm(w) revenue");
										print2.println("reterm2(w) revenue");
										
										
										print2.println("PP(w) profit");
		if (con==0)
		{  
										
										print2.println("expected expected profit");
				print2.println("cvv(w) cvar term");								
	
										//							print2.println("varlb variance lower bound");
		}
		if (con==1)
		{  
									print2.println("expected expected profit");
										
										print2.println("expectedsq expected profit");
										print2.println("variance varprofit");
										
		}
		
		if (con==2)
		{  
		print2.println("expected expected profit");
										
										print2.println("expectedsq expected profit");
										print2.println("variance varprofit");
										}

												if (con==3)
		{  
										
									print2.println("expected expected profit");
			print2.println("CVaR cvar profit");
			
			//print2.println("varlb variance lower bound");
			print2.println("cvv(w) cvar term");
			
										}
												if (con==4)
		{  	print2.println("expected expected profit");
			
	
										
										print2.println("CVaR cvar profit");
										//print2.println("varlb variance lower bound");
										print2.println("cvv(w) cvar term");
		}
												if (con==5)
		{  	print2.println("expected expected profit");
	
										
										print2.println("CVaR cvar profit");
										//print2.println("varlb variance lower bound");
		print2.println("cvv(w) cvar term");								
		}
										
										print2.println("profitim total profit ; ");
								
										print2.println("Positive variable SS; ");
										print2.println("Positive variable T; ");
				//						print2.println("Binary variable x; ");
				//						print2.println("Binary variable y; ");

										print2.println("Equations");
										
										print2.println("rrterm(w) define rrterm");
											if (con<=2)
		{  
										print2.println("rrterm2(w) define rrterm");
										
}
if (con==0)
										{
										//	print2.println("lbE");
									print2.println("cv(w)");
										}	
											if (con>2)
										{
										//print2.println("lbE");
print2.println("cv(w)");
										}
										

										
										print2.println("profit define objective function");
										print2.println("tao(w) define tao (shortage amount)");		
									//	print2.println("tao1(w) define tao (shortage amount)");		
									//	print2.println("tao2(w) define tao (shortage amount)");		
									//	print2.println("tao3(w) define tao (shortage amount)");		
										
			if (con==0)
		{	print2.println("expectedprofit define expected profit;");	
			}				
			if (con==1||con==2)
		{	print2.println("expectedprofit define expected profit");	

											print2.println("varianceprofit define variance profit;");
		}
							
		
				if (con==3|| con==4|| con==5)
		{
				print2.println("expectedprofit define expected profit");	

										print2.println("CVaRc define cvar");
										print2.println("SSS(w) define loss;");	
				}
		print2.println("expectedprofit.. expected =e=(1/10000)*sum((w),reterm(w));");
																					
		if (con==0)
		{  
		print2.println("profit.. profitim =e=expected  ;");
		print2.println("rrterm2(w).. reterm2(w)=e=sum((i),rev(i)*x(i));");
		print2.println("rrterm(w).. reterm(w)=e=reterm2(w)-oo*T(w);");
	//	print2.println("lbE.. varlb=e=(1/((10000)*(9999)))*sum((w),(reterm(w)-profitim)*(reterm(w)-profitim));");
	
			print2.println("cv(w).. cvv(w)=e=reterm(w)-profitim;");
		
		
		}
			if (con==1)
		{	
	print2.println("rrterm2(w).. reterm2(w)=e=sum((i),rev(i)*x(i));");
	print2.println("rrterm(w).. reterm(w)=e=reterm2(w)-oo*T(w);");
	print2.println("varianceprofit.. variance=e=(0.0001*sum((w),(reterm(w)-expected)*(reterm(w)-expected)) )  ;");
	print2.println("profit.. profitim =e=expected-beta*sqrt(variance)  ;");									
		}
			if (con==2)
		{
			print2.println("rrterm2(w).. reterm2(w)=e=sum((i),(SEN(w,i)*revenue-FC(i))*x(i));");
			print2.println("rrterm(w).. reterm(w)=e=reterm2(w)-oo*T(w);");
			print2.println("varianceprofit.. variance=e=(0.0001*sum((w),(reterm(w)-expected)*(reterm(w)-expected)))   ;");
			print2.println("profit.. profitim =e=expected-beta*sqrt(variance)  ;");									
					
			
	}
			if (con==3)
		{
		print2.println("profit.. profitim =e=CVaR  ;");
		print2.println("rrterm(w).. reterm(w)=e=sum((i),rev(i)*x(i))-oo*T(w);");
		print2.println("CVaRc.. CVaR =e=VAR- (1/(10000*(1-a))*sum((w),SS(w) ))   ;");
		print2.println("SSS(w).. SS(w)=G= VAR-reterm(w);");

			//print2.println("lbE.. varlb=e=(1/((10000)*(9999)))*sum((w),(cvv(w)-profitim)*(cvv(w)-profitim));");
			print2.println("cv(w).. cvv(w)=e=VAR-(SS(w)/(1-a))-profitim;");
	
		}			
					
			if (con==4)
	{	
		print2.println("profit.. profitim =e=CVaR  ;");
		print2.println("rrterm(w).. reterm(w)=e=sum((i),rev(i)*x(i))-oo*T(w);");
		print2.println("CVaRc.. CVaR =e=VAR- (1/(10000*(1-a))*sum((w),SS(w) ))   ;");
		print2.println("SSS(w).. SS(w)=G= VAR-reterm(w);");
	
	//	print2.println("lbE.. varlb=e=(1/((10000)*(9999)))*sum((w),(cvv(w)-profitim)*(cvv(w)-profitim));");
	//		print2.println("cv(w).. cvv(w)=e=VAR-(SS(w)/(1-a));");
				
				}
			if (con==5)
		{
			print2.println("profit.. profitim =e=CVaR  ;");
			print2.println("rrterm(w).. reterm(w)=e=sum((i),(SEN(w,i)*revenue-FC(i))*x(i))-oo*T(w);");
			print2.println("CVaRc.. CVaR =e=VAR- (1/(10000*(1-a))*sum((w),SS(w) ))   ;");
			print2.println("SSS(w).. SS(w)=G= VAR-reterm(w);");
		
	//		print2.println("lbE.. varlb=e=(1/((10000)*(9999)))*sum((w),(cvv(w)-profitim)*(cvv(w)-profitim));");
			print2.println("cv(w).. cvv(w)=e=VAR-(SS(w)/(1-a))-profitim;");
	
		}
										
									print2.println("tao(w).. T(w) =G=sum((i),SEN(w,i)*x(i))-Q;");
//print2.println("	tao1(w).. T(w) =L=y(w)*10000;");
//print2.println("tao2(w).. T(w) =G=sum((i),SEN(w,i)*x(i))-Q-(1-y(w))*10000;");
//print2.println("tao3(w).. T(w) =L=sum((i),SEN(w,i)*x(i))-Q+(1-y(w))*10000; ;");

						
									
										print2.println("Model NORMAL /all/ ;");
									
										//print2.println("option minlp=LINDOGlobal ;");
										
										
										print2.println("option optcr=1e-5; ");
										print2.println("option iterlim=100000000;");
										print2.println("option reslim=5000; ");
										print2.println("option domlim=20000;");
			//				if (con==0 ||con==3 ||con==4 ||con==5 )
		//{
								//		print2.println("solve  NORMAL using mip maximizing profitim ;");
		//}
		//else
		//	{*/
				print2.println("option minlp=Dicopt;");
				print2.println("solve  NORMAL using minlp maximizing profitim ;");
		//}
					
										}}}}}}}}
}
}